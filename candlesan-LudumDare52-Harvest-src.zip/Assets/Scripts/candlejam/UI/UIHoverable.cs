﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIHoverable : MonoBehaviour
{
    public bool Hovered = false;
}
